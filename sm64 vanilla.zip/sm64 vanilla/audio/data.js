export const gAudioRandom = 0  // implement me
