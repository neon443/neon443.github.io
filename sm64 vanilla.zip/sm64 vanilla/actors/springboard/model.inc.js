// ** actors/springboard/model
import * as Gbi from "../../include/gbi"

export const springboard_seg5_texture_05000018 = []
export const springboard_seg5_texture_05000818 = []
