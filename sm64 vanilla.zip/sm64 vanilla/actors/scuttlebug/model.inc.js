// ** actors/scuttlebug/model
import * as Gbi from "../../include/gbi"

export const scuttlebug_seg6_texture_06010108 = []
export const scuttlebug_seg6_texture_06010908 = []
export const scuttlebug_seg6_texture_06011908 = []
export const scuttlebug_seg6_texture_06012908 = []
export const scuttlebug_seg6_texture_06013108 = []
