// ** actors/hoot/model
import * as Gbi from "../../include/gbi"

export const hoot_seg5_texture_05000A20 = []
export const hoot_seg5_texture_05001E50 = []
export const hoot_seg5_texture_05002650 = []
