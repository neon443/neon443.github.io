// ** actors/chillychief/model
import * as Gbi from "../../include/gbi"

export const chilly_chief_seg6_texture_06000060 = []
export const chilly_chief_seg6_texture_06001060 = []
export const chilly_chief_seg6_texture_06002060 = []
