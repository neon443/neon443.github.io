// ** actors/thwomp/model
import * as Gbi from "../../include/gbi"

export const thwomp_seg5_texture_05009900 = []
export const thwomp_seg5_texture_0500A900 = []
