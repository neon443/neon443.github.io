// ** actors/heave_ho/model
import * as Gbi from "../../include/gbi"

export const heave_ho_seg5_texture_0500E9C8 = []
export const heave_ho_seg5_texture_0500F1C8 = []
export const heave_ho_seg5_texture_0500F9C8 = []
export const heave_ho_seg5_texture_050109C8 = []
export const heave_ho_seg5_texture_050111C8 = []
export const heave_ho_seg5_texture_050113C8 = []
