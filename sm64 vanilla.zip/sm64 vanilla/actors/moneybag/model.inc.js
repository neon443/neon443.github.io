// ** actors/moneybag/model
import * as Gbi from "../../include/gbi"

export const moneybag_seg6_texture_060039B0 = []
export const moneybag_seg6_texture_060049B0 = []
