// ** actors/mr_i_eyeball/model
import * as Gbi from "../../include/gbi"

export const mr_i_eyeball_seg6_texture_06000080 = []
export const mr_i_eyeball_seg6_texture_06001080 = []
