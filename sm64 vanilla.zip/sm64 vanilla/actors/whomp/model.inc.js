// ** actors/whomp/model
import * as Gbi from "../../include/gbi"

export const whomp_seg6_texture_0601C360 = []
export const whomp_seg6_texture_0601D360 = []
export const whomp_seg6_texture_0601E360 = []
export const whomp_seg6_texture_0601EB60 = []
