// ** actors/mips/model
import * as Gbi from "../../include/gbi"

export const mips_seg6_texture_0600FB80 = []
