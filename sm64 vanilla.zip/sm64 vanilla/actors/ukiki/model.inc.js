// ** actors/ukiki/model
import * as Gbi from "../../include/gbi"

export const ukiki_seg5_texture_05007BC0 = []
export const ukiki_seg5_texture_05008BC0 = []
export const ukiki_seg5_texture_05009BC0 = []
export const ukiki_seg5_texture_0500A3C0 = []
