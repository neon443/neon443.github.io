// ** actors/pokey/model
import * as Gbi from "../../include/gbi"

export const pokey_seg5_texture_05011750 = []
export const pokey_seg5_texture_05011F50 = []
export const pokey_seg5_texture_05012878 = []
