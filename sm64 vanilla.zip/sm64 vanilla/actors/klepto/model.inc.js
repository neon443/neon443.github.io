// ** actors/klepto/model
import * as Gbi from "../../include/gbi"

export const klepto_seg5_texture_05000008 = []
export const klepto_seg5_texture_05000808 = []
export const klepto_seg5_texture_05001008 = []
export const klepto_seg5_texture_05002008 = []
export const klepto_seg5_texture_05003008 = []
