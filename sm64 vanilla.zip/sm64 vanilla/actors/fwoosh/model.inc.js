// ** actors/fwoosh/model
import * as Gbi from "../../include/gbi"

export const fwoosh_seg5_texture_05015808 = []
