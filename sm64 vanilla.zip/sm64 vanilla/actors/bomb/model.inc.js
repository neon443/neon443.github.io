// ** actors/bomb/model
import * as Gbi from "../../include/gbi"

export const bomb_seg6_texture_06057AC0 = []
export const bomb_seg6_texture_06058AC0 = []
export const bomb_seg6_texture_06059AC0 = []
