// ** actors/water_mine/model
import * as Gbi from "../../include/gbi"

export const water_mine_seg6_texture_0600A4F8 = []
export const water_mine_seg6_texture_0600B4F8 = []
export const water_mine_seg6_texture_0600C4F8 = []
