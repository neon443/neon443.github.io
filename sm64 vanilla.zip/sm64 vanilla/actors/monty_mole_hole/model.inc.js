// ** actors/monty_mole_hole/model
import * as Gbi from "../../include/gbi"

export const monty_mole_hole_seg5_texture_05000040 = []
