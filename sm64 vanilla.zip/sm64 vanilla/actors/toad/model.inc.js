// ** actors/toad/model
import * as Gbi from "../../include/gbi"

export const toad_seg6_texture_06005920 = []
export const toad_seg6_texture_06006120 = []
