// Bin/sky.c

// 0x09000000
export const sky_09000000 = []
// textures/sky/rr_textures.00000.rgba16.png

// 0x09000800
export const sky_09000800 = []
// textures/sky/rr_textures.00800.rgba16.png

// 0x09001000
export const sky_09001000 = []
// textures/sky/rr_textures.01000.rgba16.png

// 0x09001800
export const sky_09001800 = []
// textures/sky/rr_textures.01800.rgba16.png

// 0x09002000
export const sky_09002000 = []
// textures/sky/rr_textures.02000.rgba16.png

// 0x09003000
export const sky_09003000 = []
// textures/sky/rr_textures.03000.rgba16.png

// 0x09003800
export const sky_09003800 = []
// textures/sky/rr_textures.03800.rgba16.png

// 0x09004800
export const sky_09004800 = []
// textures/sky/rr_textures.04800.rgba16.png

// 0x09005000
export const sky_09005000 = []
// textures/sky/rr_textures.05000.rgba16.png

// 0x09005800
export const sky_09005800 = []
// textures/sky/rr_textures.05800.rgba16.png

// 0x09006000
export const sky_09006000 = []
// textures/sky/rr_textures.06000.rgba16.png

export const texture_metal_hole = []
// textures/sky/metal_hole.rgba16.png

// 0x09007000
export const sky_09007000 = []
// textures/sky/rr_textures.07000.rgba16.png

// 0x09007800
export const sky_09007800 = []
// textures/sky/rr_textures.07800.rgba16.png

// 0x09008000
export const sky_09008000 = []
// textures/sky/rr_textures.08000.rgba16.png

// 2021-05-28 05:40:33 -0700 (Convert.rb 2021-05-28 05:31:04 -0700)
