export const cave_09000000 = []
export const cave_09001000 = []
export const cave_09001800 = []
export const cave_09002800 = []
export const cave_09003000 = []
export const cave_09003800 = []
export const cave_09004800 = []
export const cave_09005800 = []
export const cave_09006800 = []
export const cave_09007000 = []
export const cave_09007800 = []
export const cave_09008800 = []
export const cave_09009800 = []
export const cave_0900A000 = []
export const cave_0900A800 = []
export const cave_0900B800 = []
export const cave_0900C000 = []

/*
    cave_09000000
    cave_09001000
    cave_09001800
    cave_09002800
    cave_09003000
    cave_09003800
    cave_09004800
    cave_09005800
    cave_09006800
    cave_09007000
    cave_09007800
    cave_09008800
    cave_09009800
    cave_0900A000
    cave_0900A800
    cave_0900B800
    cave_0900C000

import {
    cave_09000000,
    cave_09001000,
    cave_09001800,
    cave_09002800,
    cave_09003000,
    cave_09003800,
    cave_09004800,
    cave_09005800,
    cave_09006800,
    cave_09007000,
    cave_09007800,
    cave_09008800,
    cave_09009800,
    cave_0900A000,
    cave_0900A800,
    cave_0900B800,
    cave_0900C000
} from "./textures/cave"
*/
