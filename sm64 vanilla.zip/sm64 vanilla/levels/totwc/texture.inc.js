// ** levels/totwc/texture
import * as Gbi from "../../include/gbi"

export const totwc_seg7_texture_07000000 = []
export const totwc_seg7_texture_07001000 = []
export const totwc_seg7_texture_07001800 = []
export const totwc_seg7_texture_07002000 = []
