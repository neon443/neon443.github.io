// ** levels/thi/texture
import * as Gbi from "../../include/gbi"

export const thi_seg7_texture_07000000 = []
export const thi_seg7_texture_07000800 = []
