// ** levels/bowser_3/texture
import * as Gbi from "../../include/gbi"

export const bowser_3_seg7_texture_07000000 = []
export const bowser_3_seg7_texture_07000800 = []
export const bowser_3_seg7_texture_07001000 = []
