// ** levels/vcutm/texture
import * as Gbi from "../../include/gbi"

export const vcutm_seg7_texture_07000000 = []
export const vcutm_seg7_texture_07000800 = []
export const vcutm_seg7_texture_07001800 = []
export const vcutm_seg7_texture_07002800 = []
