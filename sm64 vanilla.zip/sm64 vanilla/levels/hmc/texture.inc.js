export const hmc_seg7_texture_07000000 = []

export const hmc_seg7_texture_07001000 = []

export const hmc_seg7_texture_07002000 = []

export const hmc_seg7_texture_07003000 = []

export const hmc_seg7_texture_07003800 = []

export const hmc_seg7_texture_07004000 = []

export const hmc_seg7_texture_07004800 = []