// Wdw

// 0x07000000 - 0x07000800
export const wdw_seg7_texture_07000000 = []
// levels/wdw/0.rgba16.png

// 0x07000800 - 0x07001000
export const wdw_seg7_texture_07000800 = []
// levels/wdw/1.rgba16.png

// 0x07001000 - 0x07001800
export const wdw_seg7_texture_07001000 = []
// levels/wdw/2.rgba16.png

// 0x07001800 - 0x07002000
export const wdw_seg7_texture_07001800 = []
// levels/wdw/3.rgba16.png

// 0x07002000 - 0x07002800
export const wdw_seg7_texture_07002000 = []
// levels/wdw/4.rgba16.png

// 1620705666 - 2021-05-13 00:28:59 -0400
