// Cotmc

// 0x07000000 - 0x07001000
export const cotmc_seg7_texture_07000000 = []

// 0x07001000 - 0x07001800
export const cotmc_seg7_texture_07001000 = []

// 0x07001800 - 0x07002000
export const cotmc_seg7_texture_07001800 = []

// 0x07002000 - 0x07002800
export const cotmc_seg7_texture_07002000 = []

// 0x07002800 - 0x07003000
export const cotmc_seg7_texture_07002800 = []

// 2021-05-30 20:59:09 -0400 (Convert.rb 2021-05-29 17:49:14 -0400)
