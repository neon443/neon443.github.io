// Ttm

// 0x07000000 - 0x07001000
export const ttm_seg7_texture_07000000 = []

// 0x07000800 - 0x07001800
export const ttm_seg7_texture_07000800 = []

// 0x07001000 - 0x07002000
export const ttm_seg7_texture_07001000 = []

// 0x07001800 - 0x07002800
export const ttm_seg7_texture_07001800 = []

// 0x07002000 - 0x07003000
export const ttm_seg7_texture_07002000 = []

// 0x07002800 - 0x07003800
export const ttm_seg7_texture_07002800 = []

// 0x07003000 - 0x07004000
export const ttm_seg7_texture_07003000 = []

// 0x07004000 - 0x07005000
export const ttm_seg7_texture_07004000 = []

// 2021-05-31 18:10:41 -0400 (Convert.rb 2021-05-31 17:07:40 -0400)
