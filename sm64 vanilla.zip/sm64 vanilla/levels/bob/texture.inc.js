// Bob

// 0x07000000 - 0x07000800
export const bob_seg7_texture_07000000 = []
// levels/bob/0.rgba16.png

// 0x07000800 - 0x07001000
export const bob_seg7_texture_07000800 = []
// levels/bob/1.rgba16.png

// 0x07001000 - 0x07001800
export const bob_seg7_texture_07001000 = []
// levels/bob/2.rgba16.png

// 0x07001800 - 0x07002000
export const bob_seg7_texture_07001800 = []
// levels/bob/3.rgba16.png

// 0x07002000 - 0x07002800
export const bob_seg7_texture_07002000 = []
// levels/bob/4.rgba16.png

// 1619334742 - 2021-04-24 21:12:30 -1000
