// Bowser 1

// 0x07000000 - 0x07000002
export const bowser_1_seg7_texture_07000000 = []
// levels/bowser_1/0.rgba16.png

// 0x07001000 - 0x07001002
export const bowser_1_seg7_texture_07001000 = []
// levels/bowser_1/1.rgba16.png

// 0x07001800 - 0x07001802
export const bowser_1_seg7_texture_07001800 = []
// levels/bowser_1/2.rgba16.png

// 2021-05-28 04:16:48 -0700 (Convert.rb 2021-05-28 04:03:04 -0700)
