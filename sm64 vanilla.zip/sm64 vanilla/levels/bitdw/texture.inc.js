// Bitdw

// 0x07000000 - 0x07000002
export const bitdw_seg7_texture_07000000 = []
// levels/bitdw/0.rgba16.png

// 0x07000800 - 0x07000802
export const bitdw_seg7_texture_07000800 = []
// levels/bitdw/1.rgba16.png

// 0x07001000 - 0x07001002
export const bitdw_seg7_texture_07001000 = []
// levels/bitdw/2.rgba16.png

// 0x07001800 - 0x07001802
export const bitdw_seg7_texture_07001800 = []
// levels/bitdw/3.rgba16.png

// 2021-05-28 06:03:18 -0700 (Convert.rb 2021-05-28 06:02:15 -0700)
