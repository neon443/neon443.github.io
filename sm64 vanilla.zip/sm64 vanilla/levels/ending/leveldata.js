// ** levels/ending/leveldata.c:
import * as Gbi from "../../include/gbi"

export const cake_end_texture_eu_35 = []
export const cake_end_texture_eu_36 = []
export const cake_end_texture_eu_37 = []
export const cake_end_texture_eu_38 = []
export const cake_end_texture_eu_39 = []
export const cake_end_texture_eu_40 = []
