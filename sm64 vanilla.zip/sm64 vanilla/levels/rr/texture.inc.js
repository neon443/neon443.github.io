// ** levels/rr/texture
import * as Gbi from "../../include/gbi"

export const texture_quarter_flying_carpet = []
export const rr_seg7_texture_07000800 = []
export const rr_seg7_texture_07001800 = []
