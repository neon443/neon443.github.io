// ** levels/ttc/texture
import * as Gbi from "../../include/gbi"

export const ttc_seg7_texture_07000000 = []
export const ttc_seg7_texture_07000800 = []
