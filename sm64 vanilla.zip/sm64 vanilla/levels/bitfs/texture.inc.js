// ** levels/bitfs/texture
import * as Gbi from "../../include/gbi"

export const bitfs_seg7_texture_07000000 = []
export const bitfs_seg7_texture_07001000 = []
export const bitfs_seg7_texture_07001800 = []
