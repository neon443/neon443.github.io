// Jrb

import {
    OBJECT_WITH_ACTS, OBJECT, RETURN, INIT_LEVEL, MARIO, JUMP_LINK, LOAD_MODEL_FROM_GEO, AREA,
    WARP_NODE, WHIRLPOOL, TERRAIN, MACRO_OBJECTS, SET_BACKGROUND_MUSIC, TERRAIN_TYPE, END_AREA,
    MARIO_POS, CALL, CALL_LOOP, CLEAR_LEVEL, SLEEP_BEFORE_EXIT, EXIT
} from "../../engine/LevelCommands"

import {
    MODEL_JRB_SUNKEN_SHIP, MODEL_JRB_SUNKEN_SHIP_BACK, MODEL_JRB_SHIP_LEFT_HALF_PART,
    MODEL_JRB_SHIP_RIGHT_HALF_PART, MODEL_NONE, MODEL_JRB_SHIP_BACK_LEFT_PART,
    MODEL_JRB_SHIP_BACK_RIGHT_PART, MODEL_JRB_SLIDING_BOX, MODEL_UNAGI, MODEL_BOBOMB_BUDDY,
    MODEL_JRB_ROCK, MODEL_JRB_FALLING_PILLAR, MODEL_JRB_FALLING_PILLAR_BASE,
    MODEL_JRB_FLOATING_PLATFORM, MODEL_STAR, MODEL_EXCLAMATION_BOX, MODEL_MARIO
} from "../../include/model_ids"

import {
    script_func_global_1, /*script_func_global_5,*/ script_func_global_14
} from "../global_scripts"

import { jrb_geo_000930 } from "./rock/geo.inc"

import { jrb_geo_000900 } from "./falling_pillar/geo.inc"

import { jrb_geo_000918 } from "./falling_pillar_base/geo.inc"

import { jrb_geo_000948 } from "./floating_platform/geo.inc"

import { jrb_geo_000A18 } from "./areas/1/geo.inc"

import {
    LEVEL_JRB, LEVEL_CASTLE
} from "../level_defines_constants"

import { WARP_NO_CHECKPOINT } from "../../engine/LevelCommands"

import { jrb_seg7_area_1_collision } from "./areas/1/collision.inc"

import { jrb_seg7_area_1_macro_objs } from "./areas/1/macro.inc"

import { SEQ_LEVEL_WATER } from "../../include/seq_ids"

import { TERRAIN_WATER } from "../../include/surface_terrains"

import { jrb_geo_000AFC } from "./areas/2/geo.inc"

import { jrb_seg7_area_2_collision } from "./areas/2/collision.inc"

import { jrb_seg7_area_2_macro_objs } from "./areas/2/macro.inc"

import { jrb_geo_000978, jrb_geo_000990, jrb_geo_0009B0, jrb_geo_0009C8, jrb_geo_0009E8, jrb_geo_000A00 } from "./wooden_ship/geo.inc"
import { jrb_geo_000960 } from "./sliding_box/geo.inc"

import { ALL_ACTS, ACT_1, ACT_2, ACT_3, ACT_4, ACT_5, ACT_6 } from "../../include/model_ids"

const script_func_local_1 = [
    OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SUNKEN_SHIP,           /*pos*/  2385,   3589,   3727,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvSunkenShipPart',           /*acts*/ ACT_1),
    OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SUNKEN_SHIP_BACK,      /*pos*/  2385,   3589,   3727,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvSunkenShipPart',           /*acts*/ ACT_1),
    OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SHIP_LEFT_HALF_PART,   /*pos*/  5385,  -5520,   2428,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvSunkenShipPart2',         /*acts*/ ACT_1),
    OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SHIP_RIGHT_HALF_PART,  /*pos*/  5385,  -5520,   2428,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvSunkenShipPart2',         /*acts*/ ACT_1),
    OBJECT_WITH_ACTS(/*model*/ MODEL_NONE,                      /*pos*/  5385,  -5520,   2428,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvInSunkenShip',             /*acts*/ ACT_1),
    OBJECT_WITH_ACTS(/*model*/ MODEL_NONE,                      /*pos*/  5385,  -5520,   2428,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvInSunkenShip2',           /*acts*/ ACT_1),
    //OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SHIP_LEFT_HALF_PART,   /*pos*/  4880,    820,   2375,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvShipPart3',                /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    //OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SHIP_BACK_LEFT_PART,   /*pos*/  4880,    820,   2375,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvShipPart3',                /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    //OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SHIP_RIGHT_HALF_PART,  /*pos*/  4880,    820,   2375,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvShipPart3',                /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    //OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SHIP_BACK_RIGHT_PART,  /*pos*/  4880,    820,   2375,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvShipPart3',                /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    //OBJECT_WITH_ACTS(/*model*/ MODEL_NONE,                      /*pos*/  4880,    820,   2375,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvInSunkenShip3',           /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    //OBJECT_WITH_ACTS(/*model*/ MODEL_JRB_SLIDING_BOX,           /*pos*/  4668,   1434,   2916,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvJrbSlidingBox',            /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    OBJECT_WITH_ACTS(/*model*/ MODEL_UNAGI,                     /*pos*/  6048,  -5381,   1154,  /*angle*/ 0,  340,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvUnagi',                      /*acts*/ ACT_1),
    OBJECT_WITH_ACTS(/*model*/ MODEL_UNAGI,                     /*pos*/  8270,  -3130,   1846,  /*angle*/ 0,  285,  0,  /*behParam*/ 0x01010000,  /*beh*/ 'bhvUnagi',                      /*acts*/ ACT_2),
    OBJECT_WITH_ACTS(/*model*/ MODEL_UNAGI,                     /*pos*/  6048,  -5381,   1154,  /*angle*/ 0,  340,  0,  /*behParam*/ 0x02020000,  /*beh*/ 'bhvUnagi',                      /*acts*/ ACT_3 | ACT_4 | ACT_5 | ACT_6),
    OBJECT_WITH_ACTS(/*model*/ MODEL_NONE,                      /*pos*/  4988,  -5221,   2473,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvJetStream',                 /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    OBJECT(/*model*/ MODEL_NONE,                      /*pos*/ -1800,  -2812,  -2100,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x02000000,  /*beh*/ 'bhvTreasureChestsJrb'),
    OBJECT_WITH_ACTS(/*model*/ MODEL_BOBOMB_BUDDY,              /*pos*/ -1956,   1331,   6500,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvBobombBuddyOpensCannon',  /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    RETURN(),
];

const script_func_local_2 = [
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  1834,  -2556,  -7090,  /*angle*/ 0,  194,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -2005,  -2556,  -3506,  /*angle*/ 0,  135,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  1578,  -2556,  -5554,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/    42,  -2556,  -6578,  /*angle*/ 0,  135,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  -981,  -2556,  -5298,  /*angle*/ 0,  255,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -6549,   1536,   4343,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  1322,  -2556,  -3506,  /*angle*/ 0,  165,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  6442,  -2556,  -6322,  /*angle*/ 0,  135,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  3882,  -2556,  -5042,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  1497,   1741,   7810,  /*angle*/ 0,   14,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -3978,   1536,    -85,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -5228,   1230,   2106,  /*angle*/ 0,  323,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -7481,   1536,    185,  /*angle*/ 0,  149,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -5749,   1536,  -1113,  /*angle*/ 0,  255,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -5332,   1434,   1023,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  -815,   -613,   3556,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -3429,    819,   4948,  /*angle*/ 0,  284,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -1940,    410,   2377,  /*angle*/ 0,  194,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/ -1798,   -716,   4330,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  -845,    922,   7668,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  6741,  -2886,   3556,  /*angle*/ 0,  135,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/   255,   -101,   4719,  /*angle*/ 0,   45,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  1787,   -306,   5133,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  1079,   -613,   2299,  /*angle*/ 0,   75,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  2931,  -1697,    980,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  3036,  -4709,   4027,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  4222,  -1125,   7083,  /*angle*/ 0,  104,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  6650,   -613,   4941,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  5764,  -4709,   4427,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  3693,  -4709,    856,  /*angle*/ 0,  135,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  7981,    410,   2704,  /*angle*/ 0,  165,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  2917,  -3046,   4818,  /*angle*/ 0,  241,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_JRB_ROCK,                  /*pos*/  5896,   -393,   -123,  /*angle*/ 0,  315,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvRockSolid'),
    OBJECT(/*model*/ MODEL_NONE,                      /*pos*/    53,   2355,   2724,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00290000,  /*beh*/ 'bhvPoleGrabbing'),
    OBJECT(/*model*/ MODEL_NONE,                      /*pos*/   659,   2560,   3314,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00290000,  /*beh*/ 'bhvPoleGrabbing'),
    OBJECT(/*model*/ MODEL_NONE,                      /*pos*/  1087,   2150,   3798,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00290000,  /*beh*/ 'bhvPoleGrabbing'),
    OBJECT(/*model*/ MODEL_NONE,                      /*pos*/ -2535,   1075,   6113,  /*angle*/ 0,    0,  0,  /*behParam*/ 0x00610000,  /*beh*/ 'bhvPoleGrabbing'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR,        /*pos*/  2078,  -2863,  -4696,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvFallingPillar'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR,        /*pos*/ -1403,  -2863,  -4696,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvFallingPillar'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR,        /*pos*/ -1096,  -2863,  -3262,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvFallingPillar'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR,        /*pos*/   337,  -2863,  -5106,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvFallingPillar'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR,        /*pos*/  2078,  -2863,  -6232,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvFallingPillar'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR,        /*pos*/  4330,  -2863,  -5618,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvFallingPillar'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR_BASE,   /*pos*/  2078,  -2966,  -4696,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvPillarBase'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR_BASE,   /*pos*/ -1403,  -2966,  -4696,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvPillarBase'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR_BASE,   /*pos*/ -1096,  -2966,  -3262,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvPillarBase'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR_BASE,   /*pos*/   337,  -2966,  -5106,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvPillarBase'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR_BASE,   /*pos*/  2078,  -2966,  -6232,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvPillarBase'),
    OBJECT(/*model*/ MODEL_JRB_FALLING_PILLAR_BASE,   /*pos*/  4330,  -2966,  -5618,  /*angle*/ 0,   90,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvPillarBase'),
    OBJECT(/*model*/ MODEL_JRB_FLOATING_PLATFORM,     /*pos*/ -1059,   1025,   7072,  /*angle*/ 0,  247,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvJrbFloatingPlatform'),
    OBJECT(/*model*/ MODEL_NONE,                      /*pos*/ -4236,  1044,  2136,    /*angle*/ 0,    0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvInsideCannon'),
    RETURN(),
];

const script_func_local_3 = [
    OBJECT_WITH_ACTS(/*model*/ MODEL_NONE,             /*pos*/ 4900,   2400,    800,  /*angle*/ 0,  0,  0,  /*behParam*/ 0x03000000,  /*beh*/ 'bhvHiddenRedCoinStar',  /*acts*/ ALL_ACTS),
//#ifdef VERSION_JP
//    OBJECT_WITH_ACTS(/*model*/ MODEL_STAR,             /*pos*/ 1540,   2160,   2130,  /*angle*/ 0,  0,  0,  /*behParam*/ 0x04000000,  /*beh*/ 'bhvStar',                  /*acts*/ ALL_ACTS),
//#else
    OBJECT_WITH_ACTS(/*model*/ MODEL_EXCLAMATION_BOX,  /*pos*/ 1540,   2160,   2130,  /*angle*/ 0,  0,  0,  /*behParam*/ 0x04080000,  /*beh*/ 'bhvExclamationBox',       /*acts*/ ALL_ACTS),
//#endif
    //OBJECT_WITH_ACTS(/*model*/ MODEL_STAR,             /*pos*/ 5000,  -4800,   2500,  /*angle*/ 0,  0,  0,  /*behParam*/ 0x05000000,  /*beh*/ 'bhvStar',                  /*acts*/ ACT_2 | ACT_3 | ACT_4 | ACT_5 | ACT_6),
    RETURN(),
];

const script_func_local_4 = [
    OBJECT(/*model*/ MODEL_NONE,             /*pos*/  400,   -350,  -2700,  /*angle*/ 0,  0,  0,  /*behParam*/ 0x00000000,  /*beh*/ 'bhvTreasureChestsShip'),
    RETURN(),
];

const script_func_local_5 = [
    RETURN(),
];

export const level_jrb_entry = [
    INIT_LEVEL(),
    MARIO(/*model*/ MODEL_MARIO,  /*behParam*/ 0x00000001,  /*beh*/ 'bhvMario'),
    JUMP_LINK(script_func_global_1),
    //JUMP_LINK(script_func_global_5),
    JUMP_LINK(script_func_global_14),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_SHIP_LEFT_HALF_PART,   jrb_geo_000978),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_SHIP_BACK_LEFT_PART,   jrb_geo_0009B0),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_SHIP_RIGHT_HALF_PART,  jrb_geo_0009E8),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_SHIP_BACK_RIGHT_PART,  jrb_geo_000A00),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_SUNKEN_SHIP,           jrb_geo_000990),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_SUNKEN_SHIP_BACK,      jrb_geo_0009C8),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_ROCK,                  jrb_geo_000930),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_SLIDING_BOX,           jrb_geo_000960),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_FALLING_PILLAR,        jrb_geo_000900),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_FALLING_PILLAR_BASE,   jrb_geo_000918),
    LOAD_MODEL_FROM_GEO(MODEL_JRB_FLOATING_PLATFORM,     jrb_geo_000948),

    AREA(/*index*/ 1,  jrb_geo_000A18),
        OBJECT(/*model*/ MODEL_NONE,  /*pos*/ -6750,  2126,  1482,  /*angle*/ 0,  90,  0,  /*behParam*/ 0x000A0000,  /*beh*/ 'bhvSpinAirborneWarp'),
        WARP_NODE(/*id*/ 0x0A,  /*destLevel*/ LEVEL_JRB,  /*destArea*/ 0x01,  /*destNode*/ 0x0A,  /*flags*/ WARP_NO_CHECKPOINT),
        WARP_NODE(/*id*/ 0xF3,  /*destLevel*/ LEVEL_JRB,  /*destArea*/ 0x02,  /*destNode*/ 0x0A,  /*flags*/ WARP_NO_CHECKPOINT),
        WARP_NODE(/*id*/ 0xF0,  /*destLevel*/ LEVEL_CASTLE,  /*destArea*/ 0x01,  /*destNode*/ 0x35,  /*flags*/ WARP_NO_CHECKPOINT),
        WARP_NODE(/*id*/ 0xF1,  /*destLevel*/ LEVEL_CASTLE,  /*destArea*/ 0x01,  /*destNode*/ 0x67,  /*flags*/ WARP_NO_CHECKPOINT),
        //WHIRLPOOL(/*unk2*/ 0,  /*unk3*/ 3,  /*pos*/ 4979,  -5222,  2482,  /*strength*/ -30),
        JUMP_LINK(script_func_local_1),
        JUMP_LINK(script_func_local_2),
        JUMP_LINK(script_func_local_3),
        TERRAIN(/*terrainData*/ jrb_seg7_area_1_collision),
        MACRO_OBJECTS(/*objList*/ jrb_seg7_area_1_macro_objs),
        SET_BACKGROUND_MUSIC(/*settingsPreset*/ 0x0003,  /*seq*/ SEQ_LEVEL_WATER),
        TERRAIN_TYPE(/*terrainType*/ TERRAIN_WATER),
    END_AREA(),

    AREA(/*index*/ 2,  jrb_geo_000AFC),
        OBJECT(/*model*/ MODEL_NONE,  /*pos*/ 928,  1050,  -1248,  /*angle*/ 0,  180,  0,  /*behParam*/ 0x000A0000,  /*beh*/ 'bhvSwimmingWarp'),
        WARP_NODE(/*id*/ 0x0A,  /*destLevel*/ LEVEL_JRB,  /*destArea*/ 0x02,  /*destNode*/ 0x0A,  /*flags*/ WARP_NO_CHECKPOINT),
        WARP_NODE(/*id*/ 0xF0,  /*destLevel*/ LEVEL_CASTLE,  /*destArea*/ 0x01,  /*destNode*/ 0x35,  /*flags*/ WARP_NO_CHECKPOINT),
        WARP_NODE(/*id*/ 0xF1,  /*destLevel*/ LEVEL_CASTLE,  /*destArea*/ 0x01,  /*destNode*/ 0x67,  /*flags*/ WARP_NO_CHECKPOINT),
        JUMP_LINK(script_func_local_4),
        JUMP_LINK(script_func_local_5),
        TERRAIN(/*terrainData*/ jrb_seg7_area_2_collision),
        MACRO_OBJECTS(/*objList*/ jrb_seg7_area_2_macro_objs),
        SET_BACKGROUND_MUSIC(/*settingsPreset*/ 0x0003,  /*seq*/ SEQ_LEVEL_WATER),
        TERRAIN_TYPE(/*terrainType*/ TERRAIN_WATER),
    END_AREA(),

    MARIO_POS(/*area*/ 1,  /*yaw*/ 90,  /*pos*/ -6750,  1126,  1482),
    CALL(/*arg*/ 0,  /*func*/ 'LevelUpdate.lvl_init_or_update'),
    CALL_LOOP(/*arg*/ 1,  /*func*/ 'LevelUpdate.lvl_init_or_update'),
    CLEAR_LEVEL(),
    SLEEP_BEFORE_EXIT(/*frames*/ 1),
    EXIT(),
];


gLinker.level_scripts.level_jrb_entry = level_jrb_entry

// 2021-05-30 17:31:18 -0400 (Convert.rb 2021-05-29 17:49:14 -0400)
