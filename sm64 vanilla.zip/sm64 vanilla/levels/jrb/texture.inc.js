// Jrb

// 0x07000000 - 0x07000800
export const jrb_seg7_texture_07000000 = []
//#include "levels/jrb/0.rgba16.inc.c"
//};

// 0x07000800 - 0x07001800
export const jrb_seg7_texture_07000800 = []
//#include "levels/jrb/1.rgba16.inc.c"
//};

// 0x07001800 - 0x07002000
export const jrb_seg7_texture_07001800 = []
//#include "levels/jrb/2.rgba16.inc.c"
//};

// 0x07002000 - 0x07002800
export const jrb_seg7_texture_07002000 = []
//#include "levels/jrb/3.rgba16.inc.c"
//};

// 2021-05-30 17:31:18 -0400 (Convert.rb 2021-05-29 17:49:14 -0400)
