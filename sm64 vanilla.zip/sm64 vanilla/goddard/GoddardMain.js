class GoddardMain {
    constructor() {
        this.gGdUseVtxNormal = true
        this.gGdMoveScene = true
    }
}

export const GoddardMainInstance = new GoddardMain()